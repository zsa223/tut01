public class Logger {

    public void log(String id, int number) {
        System.out.println(id + ":" + number);
    }
}