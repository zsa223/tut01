public class Logger {
    /* TODO: your code */
}