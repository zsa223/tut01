public class LoggerRunnable extends Logger implements Runnable{
    /* TODO: your code */
}