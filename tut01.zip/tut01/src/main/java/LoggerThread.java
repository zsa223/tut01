public class LoggerThread extends Thread{
    /* TODO: your code */
}